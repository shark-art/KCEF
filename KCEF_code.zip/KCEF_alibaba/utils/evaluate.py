from .metrics import *
from .parser import parse_args
import math
import torch
import numpy as np
import multiprocessing
import heapq
from time import time
from operator import itemgetter
import random
from collections import defaultdict
global rec_item_set
rec_item_set = defaultdict(list)
global rec_user_item
rec_user_item = defaultdict(list)
cores = multiprocessing.cpu_count() // 2

args = parse_args()
Ks = eval(args.Ks)
# device = torch.device("cuda:" + str(args.gpu_id)) if args.cuda else torch.device("cpu")
BATCH_SIZE = args.test_batch_size
batch_test_flag = args.batch_test_flag


def DistanceCorrelation(tensor_1, tensor_2):
    channel = tensor_1.shape[0]
    zeros = torch.zeros(channel, channel).to(tensor_1.device)
    zero = torch.zeros(1).to(tensor_1.device)
    tensor_1, tensor_2 = tensor_1.unsqueeze(-1), tensor_2.unsqueeze(-1)
    """cul distance matrix"""
    a_, b_ = torch.matmul(tensor_1, tensor_1.t()) * 2, \
             torch.matmul(tensor_2, tensor_2.t()) * 2  # [channel, channel]
    tensor_1_square, tensor_2_square = tensor_1 ** 2, tensor_2 ** 2
    a, b = torch.sqrt(torch.max(tensor_1_square - a_ + tensor_1_square.t(), zeros) + 1e-8), \
           torch.sqrt(torch.max(tensor_2_square - b_ + tensor_2_square.t(), zeros) + 1e-8)  # [channel, channel]
    """cul distance correlation"""
    A = a - a.mean(dim=0, keepdim=True) - a.mean(dim=1, keepdim=True) + a.mean()
    B = b - b.mean(dim=0, keepdim=True) - b.mean(dim=1, keepdim=True) + b.mean()
    dcov_AB = torch.sqrt(torch.max((A * B).sum() / channel ** 2, zero) + 1e-8)
    dcov_AA = torch.sqrt(torch.max((A * A).sum() / channel ** 2, zero) + 1e-8)
    dcov_BB = torch.sqrt(torch.max((B * B).sum() / channel ** 2, zero) + 1e-8)
    return dcov_AB / torch.sqrt(dcov_AA * dcov_BB + 1e-8)


def ranklist_by_heapq(num1,user_pos_test, test_items, rating, Ks,user_type,user_category,item_category_list,users_type_weight,entity_gcn_emb,jj):
    item_score = {}
    for i in test_items:
        item_score[i] = rating[i-46932]
    K_max = max(Ks)
    K_max_item_score = heapq.nlargest(K_max, item_score, key=item_score.get)

    r = []
    for i in K_max_item_score:
        rec_user_item[num1].append(i)
        if i in user_pos_test:
            r.append(1)
        else:
            r.append(0)
        if i not in rec_item_set:
            rec_item_set[i] = 1
        else:
            rec_item_set[i] += 1
    auc = 0.
    return r, auc

def get_auc(item_score, user_pos_test):
    item_score = sorted(item_score.items(), key=lambda kv: kv[1])
    item_score.reverse()
    item_sort = [x[0] for x in item_score]
    posterior = [x[1] for x in item_score]

    r = []
    for i in item_sort:
        if i in user_pos_test:
            r.append(1)
        else:
            r.append(0)
    auc = AUC(ground_truth=r, prediction=posterior)
    return auc

def ranklist_by_sorted(user_pos_test, test_items, rating, Ks):
    item_score = {}
    for i in test_items:
        item_score[i] = rating[i]

    K_max = max(Ks)
    K_max_item_score = heapq.nlargest(K_max, item_score, key=item_score.get)

    r = []
    for i in K_max_item_score:
        if i in user_pos_test:
            r.append(1)
        else:
            r.append(0)
    auc = get_auc(item_score, user_pos_test)
    return r, auc

def get_performance(user_pos_test, r, auc, Ks):
    precision, recall, ndcg, hit_ratio = [], [], [], []

    for K in Ks:
        precision.append(precision_at_k(r, K))
        recall.append(recall_at_k(r, K, len(user_pos_test)))
        ndcg.append(ndcg_at_k(r, K, user_pos_test))
        hit_ratio.append(hit_at_k(r, K))

    return {'recall': np.array(recall), 'precision': np.array(precision),
            'ndcg': np.array(ndcg), 'hit_ratio': np.array(hit_ratio), 'auc': auc}


def test_one_user(num1,rate, user_list,user_type,user_category,item_category_list,users_type_weight,entity_gcn_emb,j):
    # user u's ratings for user u
    global train_user_set, test_user_set
    rating = rate
    # uid
    u = user_list
    # user u's items in the training set
    try:
        # training_items = itemgetter(*u)(train_user_set)
        training_items = train_user_set[u]
    except Exception:
        training_items = []
    # user u's items in the test set
    user_pos_test = test_user_set[u]

    all_items = set(range(46932, 273440))

    test_items = list(all_items - set(training_items))

    # if args.test_flag == 'part':
    r, auc = ranklist_by_heapq(num1,user_pos_test, test_items, rating, Ks, user_type, user_category, item_category_list,users_type_weight, entity_gcn_emb, j)
    # else:
    #     r, auc = ranklist_by_sorted(user_pos_test, test_items, rating, Ks)

    return get_performance(user_pos_test, r, auc, Ks)

def test(model, user_dict, n_params,test_batchsize,user_type,user_category,item_category_list):
    result = {'precision': np.zeros(len(Ks)),
              'recall': np.zeros(len(Ks)),
              'ndcg': np.zeros(len(Ks)),
              'hit_ratio': np.zeros(len(Ks)),
              'auc': 0.}

    global n_users, n_items
    n_items = n_params['n_items']
    n_users = n_params['n_users']

    global train_user_set, test_user_set
    train_user_set = user_dict['train_user_set']
    test_user_set = user_dict['test_user_set']

    pool = multiprocessing.Pool(cores)

    u_batch_size = BATCH_SIZE
    i_batch_size = BATCH_SIZE

    test_users = list(test_user_set.keys())
    n_test_users = len(test_users)
    n_user_batchs = n_test_users // u_batch_size + 1

    count = 0

    entity_gcn_emb,users_type_weight= model.generate()
    user_gcn_emb=entity_gcn_emb[0:n_users]
    num1=0
    for u_batch_id in range(n_user_batchs):
        batch_result = []
        start = u_batch_id * u_batch_size
        end = (u_batch_id + 1) * u_batch_size
        user_list_batch = test_users[start: end]
        user_batch = torch.LongTensor(np.array(user_list_batch))
        u_g_embeddings = user_gcn_emb[user_batch]
        # all-item test
        item_batch = torch.LongTensor(np.array(range(46932, 273440)))
        i_g_embddings = entity_gcn_emb[item_batch]
        rate_batch = model.rating(u_g_embeddings, i_g_embddings).detach()
        for j in user_list_batch:
            batch_result.append(
                test_one_user(num1,rate_batch[j - count], user_list_batch[j - count], user_type[j], user_category[j],
                              item_category_list, users_type_weight, entity_gcn_emb, j))
            num1+=1
        count += test_batchsize

        for re in batch_result:
            result['precision'] += re['precision']/n_test_users
            result['recall'] += re['recall']/n_test_users
            result['ndcg'] += re['ndcg']/n_test_users
            result['hit_ratio'] += re['hit_ratio']/n_test_users
            result['auc'] += re['auc']/n_test_users
    sum = 0
    for i in rec_user_item:
        b = 0
        for j in rec_user_item[i]:
            b += rec_item_set[j]
        b = b / n_test_users / 100
        sum += b

    print("Top 100 of all users AP: ", sum / n_test_users)
    pool.close()
    return result
