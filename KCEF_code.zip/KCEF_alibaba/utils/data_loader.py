import numpy as np
from tqdm import tqdm
import networkx as nx
import scipy.sparse as sp
from utils.parser import parse_args
import matplotlib.pyplot as plt
import random
from time import time
from collections import defaultdict
import re
import warnings
import torch
warnings.filterwarnings('ignore')

n_users = 0
n_items = 0
n_entities = 0
n_relations = 0
n_nodes = 0
train_user_set = defaultdict(list)
test_user_set = defaultdict(list)


def read_cf(file_name):
    inter_mat = list()
    lines = open(file_name, "r").readlines()
    for l in lines:
        tmps = l.strip()
        inters = [int(i) for i in tmps.split(" ")]
        u_id, pos_ids = inters[0], inters[1:]
        pos_ids = list(set(pos_ids))
        for i_id in pos_ids:
            inter_mat.append([u_id, i_id])
    return np.array(inter_mat)


def remap_item(train_data, test_data):
    global n_users, n_items
    n_users = 46932
    n_items = 205084
    print("The total number of users in the training and test sets is：",n_users)
    print("The total number of items in the training and test sets is：",n_items)
    for u_id, i_id in train_data:
        train_user_set[int(u_id)].append(int(i_id))
    for u_id, i_id in test_data:
        test_user_set[int(u_id)].append(int(i_id))



def read_triplets(file_name):
    global n_entities, n_relations, n_nodes

    can_triplets_np = np.loadtxt(file_name, dtype=np.int32)
    can_triplets_np = np.unique(can_triplets_np, axis=0)

    if args.inverse_r:
        # get triplets with inverse direction like <entity, is-aspect-of, item>
        inv_triplets_np = can_triplets_np.copy()
        inv_triplets_np[:, 0] = can_triplets_np[:, 2]
        inv_triplets_np[:, 2] = can_triplets_np[:, 0]
        inv_triplets_np[:, 1] = can_triplets_np[:, 1] + max(can_triplets_np[:, 1]) + 1
        # consider two additional relations --- 'interact' and 'be interacted'
        can_triplets_np[:, 1] = can_triplets_np[:, 1]
        inv_triplets_np[:, 1] = inv_triplets_np[:, 1]
        # get full version of knowledge graph
        triplets = np.concatenate((can_triplets_np, inv_triplets_np), axis=0)
    else:
        # consider two additional relations --- 'interact'.
        can_triplets_np[:, 1] = can_triplets_np[:, 1]
        triplets = can_triplets_np.copy()

    n_entities = max(max(triplets[:, 0]), max(triplets[:, 2])) + 1  # including items+users+outfits+categories
    print("The total number of entities is：including items+users+outfits+categories",n_entities)
    n_nodes = n_entities
    print("The total number of nodes is：", n_nodes)
    n_relations = max(triplets[:, 1]) + 1
    print("The total number of relations is：", n_relations)

    return triplets


def build_graph(triplets):
    ckg_graph = nx.MultiDiGraph()
    rd = defaultdict(list)
    rd_interect = defaultdict(list)

    print("\nBegin to load knowledge graph triples ...")
    for h_id, r_id, t_id in tqdm(triplets, ascii=True):
        ckg_graph.add_edge(h_id, t_id, key=r_id)
        rd[r_id].append([h_id, t_id])

    for h_id, r_id, t_id in tqdm(triplets, ascii=True):
        ckg_graph.add_edge(h_id, t_id, key=r_id)
        if r_id>=3 and r_id<=76:
            rd_interect[3].append([h_id, t_id])
        elif r_id>=77 and r_id<=10230:
            rd_interect[77].append([h_id, t_id])
        elif r_id>=10231 and r_id<=26978:
            rd_interect[10231].append([h_id, t_id])
        else:
            rd_interect[r_id].append([h_id, t_id])
    return ckg_graph, rd,rd_interect


def build_sparse_relational_graph(relation_dict,rd_interect):
    def _bi_norm_lap(adj):
        rowsum = np.array(adj.sum(1))

        d_inv_sqrt = np.power(rowsum, -0.5).flatten()
        d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.
        d_mat_inv_sqrt = sp.diags(d_inv_sqrt)

        # bi_lap = adj.dot(d_mat_inv_sqrt).transpose().dot(d_mat_inv_sqrt)
        bi_lap = d_mat_inv_sqrt.dot(adj).dot(d_mat_inv_sqrt)
        return bi_lap.tocoo()

    def _si_norm_lap(adj):
        rowsum = np.array(adj.sum(1))
        d_inv = np.power(rowsum, -1).flatten()# D^{-1}
        d_inv[np.isinf(d_inv)] = 0.
        d_mat_inv = sp.diags(d_inv)

        norm_adj = d_mat_inv.dot(adj)
        return norm_adj.tocoo()

    adj_mat_list = []
    adj_mat_list_interect = []
    print("Begin to build sparse relation matrix ...")
    a=relation_dict.keys()
    for r_id in tqdm(relation_dict.keys()):
        np_mat = np.array(relation_dict[r_id])
        if r_id == 0:
            cf = np_mat.copy()
            # cf[:, 1] = cf[:, 1] + n_users  # [0, n_items) -> [0, n_users+n_items)
            vals = [1.] * len(cf)
            adj = sp.coo_matrix((vals, (cf[:, 0], cf[:, 1])), shape=(n_nodes, n_nodes))
            adj_mat_list.append(adj)
        # else:
        #     vals = [1.] * len(np_mat)
        #     adj = sp.coo_matrix((vals, (np_mat[:, 0], np_mat[:, 1])), shape=(n_nodes, n_nodes))
    # norm_mat_list = [_bi_norm_lap(mat) for mat in adj_mat_list]#D^{-1/2}AD^{-1/2}
    mean_mat_list = [_si_norm_lap(mat) for mat in adj_mat_list]#D^{-1}A
    mean_mat_list[0] = mean_mat_list[0].tocsr()[:n_users, n_users:].tocoo()
    return mean_mat_list


def read_information_for_me(user_type_file,user_category_file,category_include_item_file):
    user_type=[]
    fr1 = open(user_type_file, 'r', encoding='utf-8')
    while True:
        line = fr1.readline()
        if line:
            line = line.strip('\n')
            line = line.strip(' ')
            line = line.strip(',')
            line = line.strip(';')
            user_type.append(float(line))
        else:
            break
    fr1.close()

    user_category=defaultdict(list)
    count=0
    fr1 = open(user_category_file, 'r', encoding='utf-8')
    while True:
        line = fr1.readline()
        if line:
            line = line.strip('\n')
            line = line.strip(' ')
            line = line.strip(',')
            line = line.strip(';')
            item = [i.strip() for i in re.split(' ', line)]
            for i in item:
                user_category[count].append(int(i))
            count+=1
        else:
            break
    fr1.close()

    category_include_item = defaultdict(list)
    item_category_list = {}
    for i in range(273366,273440):
        category_include_item_file1 = category_include_item_file + str(i) + ".txt"
        fr1 = open(category_include_item_file1, 'r', encoding='utf-8')
        while True:
            line = fr1.readline()
            if line:
                line = line.strip('\n')
                line = line.strip(' ')
                category_include_item[i].append(int(line))
                item_category_list[int(line)] = int(i)
            else:
                break
        fr1.close()
    return user_type,user_category,category_include_item,item_category_list

def load_data(model_args):
    global args
    args = model_args
    directory = args.data_path

    print('reading train and test user-item set ...')
    train_cf = read_cf(directory + 'train_for_user_item_KG.txt')
    test_cf = read_cf(directory + 'test_for_user_item_KG1.txt')
    remap_item(train_cf, test_cf)

    print('combinating train_cf and kg data ...')
    triplets_for_user_cate = read_triplets(directory + 'user_category_triple1.txt')
    triplets = read_triplets(directory + 'user_item_KG.txt')

    print('building the user_item_graph ...')
    graph, relation_dict,rd_interect = build_graph(triplets)

    print('building the user_category_graph ...')
    graph_for_user_cate, relation_dict_for_user_cate, rd_interect_for_user_cate = build_graph(triplets_for_user_cate)

    print('building the adj mat ...')
    # adj_mat_list, mean_mat_list = build_sparse_relational_graph(relation_dict)
    mean_mat_list= build_sparse_relational_graph(relation_dict,rd_interect)

    n_params = {
        'n_users': int(n_users),
        'n_items': int(n_items),
        'n_entities': int(n_entities),
        'n_nodes': int(n_nodes),
        'n_relations': int(n_relations)
    }

    n_params_for_user_category = {
        'n_users': int(46932),
        'n_items': int(74),
        'n_entities': int(47006),
        'n_nodes': int(47006),
        'n_relations': int(74)
    }

    user_dict = {
        'train_user_set': train_user_set,
        'test_user_set': test_user_set
    }

    print('read_information_for_me ...')
    user_type_file = directory + 'user_type.txt'
    user_category_file = directory + 'user_category.txt'
    category_include_item_file = directory + "category_include_item\\"
    user_type,user_category,category_include_item,item_category_list=read_information_for_me(user_type_file, user_category_file, category_include_item_file)

    # return user_type,user_category,category_include_item,train_cf, test_cf, user_dict, n_params, graph, \
    #        [adj_mat_list,  mean_mat_list]
    return user_type, user_category, category_include_item,item_category_list, train_cf, test_cf, user_dict, n_params, graph, mean_mat_list,\
               graph_for_user_cate,n_params_for_user_category
